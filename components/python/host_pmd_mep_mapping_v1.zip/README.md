# Mapping HA22 / HA26 / HA32 / PMD / MEP v1

## Cerrado con datos reales
- HA22: 9 registros de muestra, 20 columnas.
- HA26: 4 registros de muestra, 21 columnas.
- HA32: 19 registros de muestra, 10 columnas.
- MEP: 2 filas con datos, 18 columnas.

## PMD
La estructura de 21 columnas está cerrada con los encabezados funcionales acordados.
El archivo suministrado es Excel binario legacy `.xls`. En este entorno no existe un lector BIFF aprobado disponible, por lo que no se inventaron longitudes/nullability a partir de los valores. Se proponen tipos conservadores (identificadores como texto, importes Decimal, fecha DATE) hasta perfilar los registros con el lector de `.xls` del runtime de desarrollo.

## Hallazgos
- HA26.HAYNUMDO: dominio observado `S`; se conserva VARCHAR(1), no boolean.
- HA22.HORATR: `HH.MM.SS`.
- HA26.HORATR: `YYYY-MM-DD-HH.MM.SS.ffffff`.
- HA32.SALDO_INICIAL admite positivo, negativo y cero.
- MEP.FECHA observada `YYYYMMDD`.
