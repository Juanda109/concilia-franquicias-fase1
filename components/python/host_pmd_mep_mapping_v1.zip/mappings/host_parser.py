from csv import DictReader
from decimal import Decimal
from datetime import date, time, datetime

def _decimal(v): return None if v is None or str(v).strip()=="" else Decimal(str(v).strip())
def parse_pipe(path, expected_headers):
    with open(path, encoding="utf-8-sig", newline="") as f:
        reader=DictReader(f, delimiter="|")
        if reader.fieldnames != expected_headers:
            raise ValueError(f"Header inválido: {reader.fieldnames}")
        return list(reader)
