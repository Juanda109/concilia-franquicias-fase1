# PMD Mapping v1

Archivo real: `PMDDetalleTransacciones20260702(1).xlsx`
Hoja: `PMD_Detalle`
Registros con datos: 5
Columnas: 21

El mapping se perfila sobre los valores reales del XLSX suministrado.
Los importes se tipan Decimal/NUMERIC(24,4), Fecha de Comprobante como DATE y los identificadores/códigos se preservan como texto para evitar pérdida de ceros o formato.
