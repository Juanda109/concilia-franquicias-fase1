# Concilia Mapping Code v3

Parser físico + reglas + equivalencia Excel/Python. Ver equivalence_report.json y XLSX.
