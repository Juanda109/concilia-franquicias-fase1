from dataclasses import dataclass
from typing import Any, Callable, Mapping, Optional, Sequence

@dataclass(frozen=True)
class Rule:
    code: str
    priority: int
    result: str
    predicate: Callable[[Mapping[str, Any]], bool]

def first_match(ctx: Mapping[str, Any], rules: Sequence[Rule]) -> Optional[str]:
    for rule in sorted(rules, key=lambda r: r.priority):
        if rule.predicate(ctx):
            return rule.result
    return None

def first_match_with_code(ctx: Mapping[str, Any], rules: Sequence[Rule]):
    for rule in sorted(rules, key=lambda r: r.priority):
        if rule.predicate(ctx):
            return {"rule_code": rule.code, "result": rule.result}
    return {"rule_code": None, "result": None}
