from decimal import Decimal
from concilia_mapping.rules import Rule, first_match_with_code

CNB = {"010","011","012","110","111","112"}

def tasa_intercambio(ctx):
    if ctx.get("VALOR_TOTAL") is None or ctx.get("VALOR_INTERCAMBIO_2") is None:
        return Decimal("0")
    d = ctx["VALOR_TOTAL"] - ctx["VALOR_INTERCAMBIO_2"]
    return -d if ctx.get("TIPO_MOVIMIENTO")=="26" else d

CUENTA_RULES = [
    Rule("DEPO_CTA_001",10,"017-VR. DEPOSITOS ELECTRONICOS NAL CONSIGNADOS",
         lambda x: x.get("TIPO_MOVIMIENTO")=="06" and x.get("AMEX_NACIONAL") in ("","AMEX NACIONAL",None) and x.get("INDICADOR_CASH_BACK") not in CNB and x.get("COD_OFICINA")!="0090"),
    Rule("DEPO_CTA_002",20,"017-VR. DEPOSITOS ELECTRONICOS INTERNACIONAL CONSIGNADOS",
         lambda x: x.get("TIPO_MOVIMIENTO")=="06" and x.get("COD_OFICINA")=="0090" and x.get("AMEX_NACIONAL")!="AMEX INTERNACIONAL" and x.get("INDICADOR_CASH_BACK") not in CNB),
    Rule("DEPO_CTA_003",30,"017-VR. DEPOSITOS ELECTRONICOS INTERNACIONAL CONSIGNADOS",
         lambda x: x.get("TIPO_MOVIMIENTO")=="06" and x.get("COD_OFICINA")!="0090" and x.get("AMEX_NACIONAL")=="AMEX INTERNACIONAL" and x.get("INDICADOR_CASH_BACK") not in CNB),
    Rule("DEPO_CTA_004",40,"017-VR. REVERSIONES D.E. NACIONAL",
         lambda x: x.get("TIPO_MOVIMIENTO")=="26" and x.get("AMEX_NACIONAL") in ("","AMEX NACIONAL",None) and x.get("AMEX_NACIONAL")!="AMEX INTERNACIONAL" and x.get("INDICADOR_CASH_BACK") not in CNB and x.get("COD_OFICINA")!="0090"),
    Rule("DEPO_CTA_005",50,"017-VR. REVERSIONES D.E. INTERNACIONAL",
         lambda x: x.get("TIPO_MOVIMIENTO")=="26" and x.get("AMEX_NACIONAL") in ("","AMEX INTERNACIONAL",None) and x.get("INDICADOR_CASH_BACK") not in CNB and x.get("COD_OFICINA") in ("0090","0075")),
    Rule("DEPO_CTA_006",60,"017-OP CNBS",
         lambda x: x.get("INDICADOR_CASH_BACK") in CNB),
    Rule("DEPO_CTA_007",70,"017-VR. RET ATMs ADQUIRIENTES EN BBV NAL",
         lambda x: x.get("TIPO_MOVIMIENTO")=="02" and x.get("COD_OFICINA")!="0090"),
]

def cuenta(ctx): return first_match_with_code(ctx, CUENTA_RULES)

def tii(ctx):
    amex=ctx.get("AMEX_NACIONAL")
    ofi=ctx.get("COD_OFICINA")
    mov=ctx.get("TIPO_MOVIMIENTO")
    tasa=ctx.get("TASA_INTERCAMBIO") or Decimal("0")
    if amex=="AMEX INTERNACIONAL":
        return "017-TASA INTERBAN TD-TC D.E. VISA TII INTER"
    if amex!="AMEX INTERNACIONAL" and ofi=="0090" and mov in {"02","06","26"}:
        return "017-TASA INTERBAN TD-TC D.E. VISA TII INTER"
    if tasa != 0:
        return "017-ASC -CANJE ENVI. ADQUIRENTE- BINES NAL T. I.-MP TII NAL"
    return None

def comision_atm(ctx):
    if ctx.get("TIPO_MOVIMIENTO") in {"02","42"} and ctx.get("COD_OFICINA")!="0090":
        # Exact result of the Excel formula. Header says $2.888; formula says $3.088.
        return "017-VR. COMISIONES ADQ EN ATMs BBV $3.088"
    return None

def tii_5130(ctx):
    if ctx.get("TII")=="017-TASA INTERBAN TD-TC D.E. VISA TII INTER" and ctx.get("AMEX_NACIONAL")=="AMEX INTERNACIONAL":
        return "017-TII AMEX INTERNACIONAL"
    return None

def classify_amex(raw_line: str, national_bins: set[str]):
    # Excel: only enters classification when positions 59='0' and 60='3';
    # lookup uses six chars beginning at position 60.
    if len(raw_line) < 65 or raw_line[58:59]!="0" or raw_line[59:60]!="3":
        return ""
    bin6=raw_line[59:65]
    return "AMEX NACIONAL" if bin6 in national_bins else "AMEX INTERNACIONAL"
