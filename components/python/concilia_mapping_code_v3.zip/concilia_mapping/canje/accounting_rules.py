from decimal import Decimal
from concilia_mapping.rules import Rule, first_match_with_code

D = "DEBITO"
C = "CREDITO"

def _in(v, *xs): return v in xs
def _not_in(v, *xs): return v not in xs

CUENTA_RULES = [
    Rule("CANJE_CTA_001", 10, "017-CANJE RECIBIDO TARJETA DEBITO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and x.get("ESPACIOS")!="CNB" and _in(x.get("TX"),"02","06")),
    Rule("CANJE_CTA_002", 20, "017-ORIGINAL PAGOS A TARJETAS DEBITO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and str(x.get("BIN_DEST"))!="404279" and x.get("ESPACIOS")!="CNB" and x.get("TX")=="04"),
    Rule("CANJE_CTA_003", 30, "017-ORIGINAL PAGOS A TARJETAS DEBITO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and str(x.get("BIN_DEST"))=="404279" and x.get("ESPACIOS")!="CNB" and _in(x.get("TX"),"04","22","26")),
    Rule("CANJE_CTA_004", 40, "017-CANJE RECIBIDO TARJETA DEBITO REVERSIONES",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and _not_in(str(x.get("BIN_DEST")),"404279","462550") and x.get("ESPACIOS")!="CNB" and _in(x.get("TX"),"22","26")),
    Rule("CANJE_CTA_005", 50, "017-CANJE RECIBIDO TARJETA DEBITO REVERSIONES REGALO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and str(x.get("BIN_DEST"))=="462550" and x.get("ESPACIOS")!="CNB" and _in(x.get("TX"),"22","26")),
    Rule("CANJE_CTA_006", 60, "017-CANJE RECIBIDO TARJETA DEBITO REVERSIONES PAGOS",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and str(x.get("BIN_DEST"))!="404279" and x.get("ESPACIOS")!="CNB" and x.get("TX")=="24"),
    Rule("CANJE_CTA_007", 70, "017-OP CNBS",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and x.get("ESPACIOS")=="CNB"),
    Rule("CANJE_CTA_008", 80, "017-DEVOLUCION VTA NAL",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="16"),
    Rule("CANJE_CTA_009", 90, "017-REPRESENTACION VENTA NAL (CENTRO 730)",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TX")=="36"),
    Rule("CANJE_CTA_010",100, "017-ORIGINAL REEMBOLSOS DEBITO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and x.get("TX")=="08"),
    Rule("CANJE_CTA_011",110, "017-ORIGINAL REEMBOLSOS CREDITO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="08"),
    Rule("CANJE_CTA_012",120, "017-COMISIONES NO EXITOSAS TD Y TC IMPUTABLES BANCO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TX")=="42" and str(x.get("BIN_DEST"))!="439467" and _not_in(x.get("MOT_COB"),"15","16","03") and _in(x.get("TIPO"),C,D)),
    Rule("CANJE_CTA_013",130, "017-COMISIONES NO EXITOSAS TD Y TC TIPO 15 Y 16",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TX")=="42" and str(x.get("BIN_DEST"))!="439467" and _not_in(x.get("MOT_COB"),"05","06","03") and _in(x.get("TIPO"),C,D)),
    Rule("CANJE_CTA_014",140, "017-CANJE RECIBIDO TARJETA CREDITO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and _in(x.get("TX"),"06","02")),
    Rule("CANJE_CTA_015",150, "017-CANJE RECIBIDO TARJETA CREDITO PAGOS",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="04"),
    Rule("CANJE_CTA_016",160, "017-CANJE RECIBIDO TARJETA CREDITO REVERSION VENTAS 26 VLR. TOTAL",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="26"),
    Rule("CANJE_CTA_017",170, "017-CANJE RECIBIDO TC REVERSION AVANCES 22",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="22"),
    Rule("CANJE_CTA_018",180, "017-CANJE RECIBIDO TC REVERSION PAGOS 24",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="24"),
    Rule("CANJE_CTA_019",190, "017-VISA PAGOS",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")=="EFIPAGO" and x.get("TX") not in ("Totales","56")),
    Rule("CANJE_CTA_020",200, "017-CANJE UTILIZACION VISA VALE",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")=="VISA VALE" and x.get("TX")!="Totales"),
    Rule("CANJE_CTA_021",210, "017-REPRESENTACION AVANCE NAL TD (CENTRO 730)",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==D and x.get("ESPACIOS")!="CNB" and x.get("TX")=="32"),
    Rule("CANJE_CTA_022",220, "017-NOTAS DEBITO CANJE RECIBIDO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TX")=="42" and str(x.get("BIN_DEST"))!="439467" and x.get("MOT_COB")=="03" and _in(x.get("TIPO"),C,D)),
    Rule("CANJE_CTA_023",230, "017-NOTAS CREDITO CANJE RECIBIDO",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TX")=="44" and str(x.get("BIN_DEST"))!="439467" and x.get("MOT_COB")=="03" and _in(x.get("TIPO"),C,D)),
    Rule("CANJE_CTA_024",240, "017-TP 12 DEVO AVANCE",
         lambda x: x.get("COD_ERROR")=="00" and x.get("TIPO")==C and x.get("TX")=="12"),
]

COMISION_RULES = [
    Rule("CANJE_COM_001",10,"017-COMISIONES EXIT. TARJETA DEBITO ONLINE",
         lambda x: x.get("TIPO")==D and x.get("ESPACIOS")!="CNB" and x.get("TX")=="02" and x.get("COMISION_OP_EXITOSAS")==Decimal("7450")),
    Rule("CANJE_COM_002",20,"017-CJE REC VISA NAL VR COM EXIT TC BATC",
         lambda x: x.get("TIPO")==C and x.get("ESPACIOS")=="ELECTRONICO" and x.get("TX")=="02" and x.get("COMISION_OP_EXITOSAS")==Decimal("7450")),
    Rule("CANJE_COM_003",30,"017-TII RECIBIDA EMISOR VISA OP REVER VENTAS",
         lambda x: x.get("TIPO")==C and x.get("TX")=="26" and (x.get("TII_RECIBIDA") or Decimal("0")) != 0),
]

def cuenta(ctx): return first_match_with_code(ctx, CUENTA_RULES)
def cuentas_comisiones(ctx): return first_match_with_code(ctx, COMISION_RULES)

def tii_recibida(ctx):
    if ctx.get("TIPO")==C and ctx.get("TX")=="26":
        if ctx.get("VL_TOTAL") is None or ctx.get("VL_INTERC") is None: return None
        return ctx["VL_TOTAL"] - ctx["VL_INTERC"]
    return None

def cuenta_880(ctx):
    if str(ctx.get("BIN_DEST")) in {"462550","417704"} and ctx.get("TIPO")==D and ctx.get("ESPACIOS")!="CNB" and ctx.get("TX") in {"02","06"}:
        return "017-CANJE RECIBIDO TARJETA DEBITO REGALO"
    return None
