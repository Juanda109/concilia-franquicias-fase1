from decimal import Decimal
from concilia_ingestion.canje_layout import parse_physical as parse_canje_physical
from concilia_ingestion.canje_rules import enrich as enrich_canje_base
from concilia_ingestion.depo_layout import parse_physical as parse_depo_physical
from concilia_mapping.canje.accounting_rules import cuenta as canje_cuenta, cuentas_comisiones, tii_recibida, cuenta_880
from concilia_mapping.depo.accounting_rules import tasa_intercambio, classify_amex, cuenta as depo_cuenta, tii as depo_tii, comision_atm, tii_5130

def parse_canje(line, bin_catalog):
    r=parse_canje_physical(line)
    r=enrich_canje_base(r,bin_catalog)
    r['TII_RECIBIDA']=tii_recibida({'TIPO':r.get('tipo'),'TX':r.get('tx'),'VL_TOTAL':r.get('vl_total'),'VL_INTERC':r.get('vl_interc')})
    ctx={'COD_ERROR':r.get('cod_error'),'TIPO':r.get('tipo'),'ESPACIOS':r.get('espacios'),'TX':r.get('tx'),'BIN_DEST':r.get('bin_dest'),'MOT_COB':r.get('mot_cob'),'COMISION_OP_EXITOSAS':r.get('comision_op_exitosas'),'TII_RECIBIDA':r.get('TII_RECIBIDA')}
    c=canje_cuenta(ctx); cc=cuentas_comisiones(ctx)
    r['cuenta']=c['result']; r['cuenta_rule_code']=c['rule_code']
    r['cuentas_comisiones']=cc['result']; r['cuentas_comisiones_rule_code']=cc['rule_code']
    r['tii_recibida_emisor_visa_op_rever_ventas']=r['TII_RECIBIDA']
    r['cuenta_880']=cuenta_880(ctx)
    return r

def parse_depo(line, amex_bins):
    r=parse_depo_physical(line)
    raw=line.ljust(282)
    r['tasa_de_intercambio']=tasa_intercambio({'TIPO_MOVIMIENTO':r.get('tipo_movimiento'),'VALOR_TOTAL':r.get('valor_total'),'VALOR_INTERCAMBIO_2':r.get('valor_intercambio_2')})
    r['amex_nacional']=classify_amex(raw,amex_bins)
    ctx={'TIPO_MOVIMIENTO':r.get('tipo_movimiento'),'AMEX_NACIONAL':r.get('amex_nacional'),'INDICADOR_CASH_BACK':r.get('indicador_cash_back'),'COD_OFICINA':r.get('cod_oficina'),'TASA_INTERCAMBIO':r.get('tasa_de_intercambio')}
    c=depo_cuenta(ctx); r['cuenta']=c['result']; r['cuenta_rule_code']=c['rule_code']
    r['tii']=depo_tii(ctx); r['comision_atm']=comision_atm(ctx)
    r['tii_5130']=tii_5130({'TII':r['tii'],'AMEX_NACIONAL':r['amex_nacional']})
    return r
