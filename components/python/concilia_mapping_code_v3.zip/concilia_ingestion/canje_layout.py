from dataclasses import dataclass
from .common import cut, dec

@dataclass(frozen=True)
class Field:
    start: int
    length: int

FIELDS = {
    'tx_raw': Field(1,2), 'bin_dest': Field(9,6), 'fecha_canje': Field(15,6),
    'tarjeta': Field(56,19), 'vl_total': Field(123,9), 'vl_interc_raw': Field(141,9),
    'plaz': Field(150,2), 'mot_cob': Field(152,2), 'cod_error': Field(198,2),
    'mo_to': Field(264,1), 'ind_cash': Field(265,1), 'xx': Field(266,2),
}

def parse_physical(line: str) -> dict:
    raw_tx = cut(line,1,2)
    try: tx = 'Totales' if int(raw_tx) % 2 else raw_tx
    except ValueError: tx = ''
    return {
        'tx': tx,
        'bin_dest': cut(line,9,6).strip(),
        'fecha_canje': cut(line,15,6),
        'ofi': None,
        'tarjeta': cut(line,56,19),
        'vl_total': dec(cut(line,123,9)),
        'vl_descue': None,
        'vl_interc_raw': dec(cut(line,141,9)),
        'plaz': cut(line,150,2),
        'mot_cob': cut(line,152,2),
        'iden_red': None,
        'cod_error': cut(line,198,2),
        'mo_to': cut(line,264,1),
        'ind_cash': cut(line,265,1),
        'xx': cut(line,266,2),
    }
