from decimal import Decimal

def classify_channel(tx: str, xx: str) -> str:
    if tx == 'Totales': return 'Totales'
    if xx.strip() == '': return 'Manual'
    if xx in {'10','11','12'}: return 'CNB'
    return 'ELECTRONICO'

def enrich(record: dict, bin_catalog: dict[str,str]) -> dict:
    tarjeta = record.get('tarjeta') or ''
    lookup_bin = tarjeta[3:9]
    tipo = bin_catalog.get(lookup_bin, '')
    record['tipo'] = tipo
    record['espacios'] = classify_channel(record['tx'], record['xx'])
    vi = record.get('vl_interc_raw')
    record['vl_interc'] = (-vi if vi is not None and record['tx']=='22' and tipo=='EFIPAGO' else vi)
    record['comision_op_exitosas'] = Decimal('7450') if record['tx']=='02' and record['bin_dest']!='439467' else None
    record['tii_recibida_emisor_visa_op_rever_ventas'] = ((record['vl_total'] or 0) - (record['vl_interc'] or 0)) if tipo=='CREDITO' and record['tx']=='26' else None
    record['cuenta_880'] = '017-CANJE RECIBIDO TARJETA DEBITO REGALO' if record['bin_dest'] in {'462550','417704'} and tipo=='DEBITO' and record['espacios']!='CNB' and record['tx'] in {'02','06'} else None
    # cuenta / cuentas_comisiones are intentionally delegated to parameterized ordered rules.
    record.setdefault('cuenta', None); record.setdefault('cuentas_comisiones', None)
    return record
