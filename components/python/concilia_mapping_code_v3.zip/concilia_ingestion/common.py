from decimal import Decimal, InvalidOperation

def cut(line: str, start: int, length: int) -> str:
    return line[start-1:start-1+length]

def dec(raw: str):
    raw = raw.strip()
    if not raw:
        return None
    try:
        return Decimal(raw)
    except InvalidOperation as exc:
        raise ValueError(f'Invalid numeric value: {raw!r}') from exc
