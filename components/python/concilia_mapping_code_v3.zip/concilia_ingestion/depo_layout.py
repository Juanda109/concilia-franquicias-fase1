from .common import cut, dec

PHYSICAL = [
('tipo_movimiento',1,2,False),('bin_fuente',3,6,False),('bin_destino',9,6,False),('fecha_del_canje',15,6,False),
('numero_del_lote',21,3,False),('numero_del_registro',24,6,False),('bin_receptor',30,6,False),('fecha_contabilizacion',36,6,False),
('numero_secuencia',42,9,False),('digito_chequeo',51,1,False),('cod_oficina',52,4,False),('no_tarjeta',56,19,False),
('no_comprobante',75,4,False),('fecha_comprobante',79,6,False),('cod_comercio',85,10,False),('porcentaje_descuento',95,4,False),
('cod_autorizacion',99,6,False),('valor_compra',105,9,True),('valor_propina',114,9,True),('valor_total',123,9,True),
('valor_descuento',132,9,True),('valor_intercambio',141,9,True),('plazo',150,2,False),('motivo_cobro',152,2,False),
('tx_anterior',154,2,False),('captura',156,1,False),('fecha_de_deposito',157,6,False),('cuenta_de_deposito',163,18,False),
('numero_de_terminal',181,5,False),('codigo_alterno',186,10,False),('tipo_de_red',196,1,False),('identificador_red_adquirente',197,1,False),
('cod_de_error',198,2,False),('identificador_reg_inconsistente',200,1,False),('valor_iva_vlor_transf',201,9,True),('vlor_retencion_compra',210,9,True),
('vlor_retencion_iva',219,9,True),('valor_deposito_neto',228,9,True),('valor_ica',237,9,True),('valor_intercambio_2',246,9,True),
('valor_iva_a_retornar',255,9,True),('indicador_mo_to_o_comercio_electro',264,1,False),('indicador_cash_back',265,3,False),('espacios',268,15,False)
]

def parse_physical(line: str) -> dict:
    if len(line) < 280:
        raise ValueError(f'DEPO record shorter than 280 chars: {len(line)}')
    line = line.ljust(282)
    out={}
    for name,start,length,is_num in PHYSICAL:
        raw=cut(line,start,length)
        out[name]=dec(raw) if is_num else raw
    return out
