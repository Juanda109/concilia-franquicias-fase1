def enrich(record: dict, amex_bins: set[str]) -> dict:
    diff=(record.get('valor_total') or 0)-(record.get('valor_intercambio_2') or 0)
    record['tasa_de_intercambio']=-diff if record.get('tipo_movimiento')=='26' else diff
    # Excel uses positions 59/60 and a lookup against 'bines amex'. Preserve exact semantics.
    tarjeta=record.get('no_tarjeta') or ''
    lookup_bin=tarjeta[4:10] if len(tarjeta)>=10 else ''
    if len(tarjeta)>=5 and tarjeta[3:5]=='03':
        record['amex_nacional']='AMEX NACIONAL' if lookup_bin in amex_bins else 'AMEX INTERNACIONAL'
    else:
        record['amex_nacional']=''
    # Accounting labels remain parameterized; the source Excel formula is the golden rule set.
    record.setdefault('cuenta',None); record.setdefault('tii',None); record.setdefault('comision_atm',None); record.setdefault('tii_5130',None)
    return record
