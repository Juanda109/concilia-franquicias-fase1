from decimal import Decimal
from concilia_mapping.canje.accounting_rules import cuenta as canje_cuenta, cuentas_comisiones, tii_recibida, cuenta_880
from concilia_mapping.depo.accounting_rules import cuenta as depo_cuenta, tasa_intercambio, tii, comision_atm, tii_5130

def test_canje_debito_base():
    c={"COD_ERROR":"00","TIPO":"DEBITO","ESPACIOS":"ELECTRONICO","TX":"02","BIN_DEST":"123456","MOT_COB":"00"}
    assert canje_cuenta(c)["result"]=="017-CANJE RECIBIDO TARJETA DEBITO"

def test_canje_cnb_priority():
    c={"COD_ERROR":"00","TIPO":"DEBITO","ESPACIOS":"CNB","TX":"02","BIN_DEST":"123456","MOT_COB":"00"}
    assert canje_cuenta(c)["result"]=="017-OP CNBS"

def test_canje_tii_recibida():
    assert tii_recibida({"TIPO":"CREDITO","TX":"26","VL_TOTAL":Decimal("100"),"VL_INTERC":Decimal("30")})==Decimal("70")

def test_canje_880():
    assert cuenta_880({"BIN_DEST":"462550","TIPO":"DEBITO","ESPACIOS":"ELECTRONICO","TX":"06"}) is not None

def test_depo_tasa_reversion():
    assert tasa_intercambio({"TIPO_MOVIMIENTO":"26","VALOR_TOTAL":Decimal("100"),"VALOR_INTERCAMBIO_2":Decimal("30")})==Decimal("-70")

def test_depo_cnb():
    c={"TIPO_MOVIMIENTO":"06","AMEX_NACIONAL":"","INDICADOR_CASH_BACK":"010","COD_OFICINA":"0001"}
    assert depo_cuenta(c)["result"]=="017-OP CNBS"

def test_depo_comision_exact_excel_result():
    assert comision_atm({"TIPO_MOVIMIENTO":"42","COD_OFICINA":"0001"}).endswith("$3.088")

def test_depo_tii5130():
    c={"TII":"017-TASA INTERBAN TD-TC D.E. VISA TII INTER","AMEX_NACIONAL":"AMEX INTERNACIONAL"}
    assert tii_5130(c)=="017-TII AMEX INTERNACIONAL"
