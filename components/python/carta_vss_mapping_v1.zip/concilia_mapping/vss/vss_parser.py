import re
from decimal import Decimal

def amount(value):
    if value is None: return None
    return Decimal(value.replace(",",""))

def split_nature(value):
    m=re.fullmatch(r"([\d,]+\.\d{2})(CR|DB)?",value.strip())
    if not m: return None, None
    return amount(m.group(1)), m.group(2)

class VSSParser:
    def split_pages(self,text):
        return [p for p in text.split("\f") if p.strip()]

    def page_header(self,page):
        def one(pattern):
            m=re.search(pattern,page,re.M)
            return m.group(1).strip() if m else None
        return {
          "report_id":one(r"REPORT ID:\s*(VSS-\d+)"),
          "page":int(one(r"PAGE:\s*(\d+)") or 0),
          "proc_date_raw":one(r"PROC DATE:\s*(\d{2}[A-Z]{3}\d{2})"),
          "report_date_raw":one(r"REPORT DATE:\s*(\d{2}[A-Z]{3}\d{2})"),
          "settlement_currency":one(r"SETTLEMENT CURRENCY:\s*([A-Z]{3})"),
          "clearing_currency":one(r"CLEARING CURRENCY:\s*([A-Z]{3})"),
        }

    def validate_cross_report(self,text):
        a=re.search(r"NET SETTLEMENT AMOUNT\s+[\d,]+\.\d{2}\s+[\d,]+\.\d{2}\s+([\d,]+\.\d{2})(CR|DB)",text)
        b=re.search(r"FINAL SETTLEMENT NET AMOUNT\s+([\d,]+\.\d{2})(CR|DB)",text)
        if not a or not b: return {"valid":False,"reason":"totales no encontrados"}
        return {"valid":a.group(1)==b.group(1) and a.group(2)==b.group(2),
                "vss110":a.group(1)+a.group(2),"vss115":b.group(1)+b.group(2)}
