import re
from decimal import Decimal
from datetime import date

MONTHS={"ENE":1,"FEB":2,"MAR":3,"ABR":4,"MAY":5,"JUN":6,"JUL":7,"AGO":8,"SEP":9,"OCT":10,"NOV":11,"DIC":12}

def parse_amount(value: str):
    v=value.strip()
    negative=v.endswith("-")
    if negative: v=v[:-1]
    v=v.replace(".","").replace(",","")
    if not v: return None
    amount=Decimal(v)
    return -amount if negative else amount

def parse_process_date(text: str):
    m=re.search(r"FECHA PROCESO:\s*(\d{2})/([A-Z]{3})/(\d{2})",text,re.I)
    if not m: return None
    return date(2000+int(m.group(3)),MONTHS[m.group(2).upper()],int(m.group(1)))

class CartaCEI240AParser:
    SHEET_NAME="CEI  240A"
    REPORT_CODE="CEI0240A"

    def validate(self, lines):
        text="\n".join(lines)
        if self.REPORT_CODE not in text:
            raise ValueError("No corresponde a CEI0240A")
        if "DEPOSITOS ELECTRONICOS" not in text.upper():
            raise ValueError("Título DEPOSITOS ELECTRONICOS no encontrado")

    def metadata(self, lines):
        text="\n".join(lines)
        bank=re.search(r"BANCO RECEPTOR:\s*(.*?)\s*-\s*(\d+)",text,re.I)
        return {
            "banco_receptor": bank.group(1).strip() if bank else None,
            "codigo_banco_receptor": bank.group(2) if bank else None,
            "fecha_proceso": parse_process_date(text)
        }
