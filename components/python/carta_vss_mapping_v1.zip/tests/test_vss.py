from pathlib import Path
from concilia_mapping.vss.vss_parser import VSSParser

def test_vss_pages():
    text=Path('/mnt/data/VSS BBVA 02 JULIO(4).txt').read_text(encoding="utf-8",errors="replace")
    p=VSSParser()
    pages=p.split_pages(text)
    assert len(pages)==4
    headers=[p.page_header(x) for x in pages]
    assert [x["report_id"] for x in headers]==["VSS-110","VSS-115","VSS-120","VSS-120"]
    assert headers[2]["clearing_currency"]=="COP"
    assert headers[3]["clearing_currency"]=="USD"

def test_vss_cross_report():
    text=Path('/mnt/data/VSS BBVA 02 JULIO(4).txt').read_text(encoding="utf-8",errors="replace")
    assert VSSParser().validate_cross_report(text)["valid"] is True
