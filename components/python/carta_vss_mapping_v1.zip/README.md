# Carta CEI 240A + VSS mapping v1

## Carta
- Workbook: 090926(3).xlsx
- Hoja usada: `CEI  240A` exclusivamente.
- Líneas no vacías: 39
- Bloques detectados: 7
- Banco receptor observado: BBVA
- Código banco: 0013
- Fecha proceso: 2026-09-09
- Parser normaliza puntos de miles y signo negativo al final.

## VSS
- Archivo: VSS BBVA 02 JULIO(4).txt
- Páginas: 4
- Secuencia: VSS-110 p1, VSS-115 p1, VSS-120 p1, VSS-120 p2
- VSS-120 cambia CLEARING_CURRENCY de COP a USD entre páginas.
- Control VSS-110 NET SETTLEMENT vs VSS-115 FINAL SETTLEMENT: True.

## Modelo
Carta → CON_CARTA_COMP_RESULTADO.
VSS → CON_VSS_REPORTE + CON_VSS_DETALLE.

## Pendiente antes de producción
Completar pruebas de extracción posicional de todas las líneas Carta y de todas las variantes de detalle VSS con más jornadas, sin cambiar el contrato ya definido.
